public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
	byte age = 30;
	int mark =500;
	char sec = 'A';
	long salary = 1000000L;
	float cgpa = 9.4f;
	double percentage = 90.8888888;
	System.out.println(age);
System.out.println(mark);
System.out.println(sec);
System.out.println(salary);
System.out.println(cgpa);
System.out.println(percentage);
    }
}